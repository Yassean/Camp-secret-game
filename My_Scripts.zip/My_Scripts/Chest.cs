using UnityEngine;

namespace chestScript
{
public class Chest : MonoBehaviour
{
        public Animator BoxOp;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
        public void open()
        {
            BoxOp.SetBool("open", true);
            Debug.Log("opened");
        }
}

}
