using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using CameraDoorScript;

public class flash : MonoBehaviour
{
    [SerializeField]
    private float fuseTime = 2;
        private Camera cam;
    public static blindlnessEffect activeInstance;
    private void Start()
    {
        
        cam = Camera.main;
        Invoke("Explode", fuseTime);
    }
    private void Explode()
    {
        
        if (checkVisibility())
        {
            Debug.Log("go blind");
            blindlnessEffect.activeInstance.GoBlind();
        }
        else
        {
            Debug.Log("not affected");
        }
        
    }
    private bool checkVisibility()
    {
        var planes = GeometryUtility.CalculateFrustumPlanes(cam);
        var point = transform.position;

        foreach (var p in planes)
        {
            if (p.GetDistanceToPoint(point) > 0)
            {
                Ray ray = new Ray(cam.transform.position, transform.position - cam.transform.position);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                    return hit.transform.gameObject == this.transform.gameObject;
                }
                else
                {
                    return false;
                }
            }
            else return false;
        }
        return false;
    }
    //  public GameObject whiteImage;
    //  public GameObject whiteNoise;
    //  public GameObject fall;
    //  public GameObject bang;
    ////  public bool Cflash;
    //  public float timer ;
    ////  private Ray ray;
    ////  private RaycastHit raycastHit;
    //  public float radius;
    //  public float maxDistance;
    //  public LayerMask layerMask;
    //  public void Start()
    //  {
    //      AudioListener.pause = false;
    //      fall.SetActive(true);
    //      StartCoroutine(CountDownCoroutine(timer));
    //  }
    //  IEnumerator CountDownCoroutine(float time)
    //  { 
    //      yield return new WaitForSeconds(time);

    //      bang.SetActive(true);
    //      whiteNoise.SetActive(true);
    //if (Cflash)
    //{
    //whiteImage.SetActive(true);
    //}

    //    yield return new WaitForSeconds(time+3);
    //    whiteImage.SetActive(false);
    //    bang.SetActive(false);
    //    whiteNoise.SetActive(false) ;
    //    Destroy(gameObject);
    //}
    //  void Update()
    //  {
    //RaycastHit hit;
    //if (Physics.SphereCast(transform.position,radius,-transform.up,out hit,maxDistance))
    //{
    //    Debug.Log(hit.collider.gameObject);
    //    Cflash = true;
    //}
    //else
    //{
    //    Cflash = false;
    //}


    //RaycastHit hit;
    //if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.negativeInfinity), out hit, Mathf.Infinity))
    //{
    //    if (hit.transform.GetComponent<CameraDoorScript.CameraInteract>())
    //    {
    //    Cflash = true;
    //    }
    //    else
    //    {
    //    Cflash = false;
    //    }
    //}
    //else
    //{

    //}
    // }


}


