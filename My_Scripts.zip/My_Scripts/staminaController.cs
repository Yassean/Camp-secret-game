using StarterAssets;
using UnityEngine;
using UnityEngine.UI;

public class staminaController : MonoBehaviour
{
    public float stamina = 100f;
    public bool slowed=false;
    [SerializeField] private float maxStam = 100f;
    [HideInInspector] public bool hasGenerated=true;
    [HideInInspector] public bool isSprinting;
    [Range(0,50)][SerializeField] public float staminaDrain = 0.4f;
    [Range(0, 50)] [SerializeField] private float staminaRegen = 0.5f;
    [SerializeField] private int SlowedRunSpeed = 4;
    [SerializeField] private int NormalRunSpeed = 8;
    [SerializeField] private Image StaminaProgress=null;
    [SerializeField] private CanvasGroup staminaCanvisGroup = null;

    private FirstPersonController playerController;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        playerController = GetComponent<FirstPersonController>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!isSprinting)
        {
            if (stamina <= maxStam - 0.01f)
            {
                stamina += staminaRegen * Time.deltaTime;
                UpdateStamina(1);
                if (stamina >= 0&& stamina<maxStam)
                {
                    staminaCanvisGroup.alpha = 1;
                    playerController.setRunSpeed(NormalRunSpeed);
                    
                    hasGenerated = false;
                }else if (stamina >= maxStam)
                {
                    staminaCanvisGroup.alpha = 0;
                    hasGenerated = true;
                }
            }

        }
        
    }
    //public void StaminaJump()
    //{
    //    if (stamina >= (maxStam * jumpCost / maxStam))
    //    {

    //    }
    //}
    public void Sprinting()
    {
        if (stamina>0&&!slowed)
        {
            isSprinting = true;
            stamina -= staminaDrain * Time.deltaTime;
            UpdateStamina(1);
            
        }else if (stamina <= 0||slowed)
            {
                playerController.setRunSpeed(SlowedRunSpeed);
                hasGenerated = false;
                staminaCanvisGroup.alpha = 0;
            }
    }
    void UpdateStamina (int value)
    {
        StaminaProgress.fillAmount = stamina / maxStam;
        if (value == 0)
        {
            staminaCanvisGroup.alpha = 0;
        }
        else
        {
            staminaCanvisGroup.alpha = 1;
        }
    }
}
