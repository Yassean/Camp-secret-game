using UnityEngine;

public class enemyManager : MonoBehaviour
{
    #region Singleton
    public static enemyManager instance;
    private void Awake()
    {
        instance = this;
    }
    #endregion
    public GameObject enemy;
}
