using System.Collections;
using UnityEngine;
using UnityEngine.AI;
public class enemyController : MonoBehaviour
{
    //  public float lookRadius=10f;
    public  Animator animator;
    GameObject target;
    NavMeshAgent agent;
    public LookAt look;
    private float couuntDownTime=30f;
    public GameObject eat;
    public GameObject scream;
    public bool rage;
    public GameObject walk;
    //public GameObject cam1;
    //public GameObject cam2;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
      //  animator = GetComponent<Animator>();
        target = playerManager.instance.player;
        agent = GetComponent<NavMeshAgent>();
        StartCoroutine(CountDownCoroutine(couuntDownTime));
    }

    IEnumerator CountDownCoroutine(float time)
    {
        yield return new WaitForSeconds(time);
        if (!rage)
        {
            Destroy(gameObject);
        }
        
    }
    // Update is called once per frame
    void Update()
    {
        if (agent.velocity.magnitude>2)
        {
            walk.SetActive(true);
        }
        else
        {
            walk.SetActive(false);
        }
        if (target.tag == "PlayerS")
        {
            rage = true;
        }
            agent.SetDestination(target.transform.position);
        FaceTarget();
        animator.SetFloat("Speed", agent.velocity.magnitude);
     
        
    }
    void FaceTarget()
    {
        Vector3 direction = (target.transform.position - transform.position).normalized;
        Quaternion lookRotation = Quaternion.LookRotation(new Vector3(direction.x, 0, direction.z));
        transform.rotation=Quaternion.Slerp(transform.rotation, lookRotation, 5 * Time.deltaTime);
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player"|| other.gameObject.tag == "PlayerS")
        {
            Debug.Log("player catched");
            look.enabled = true;
            animator.SetBool("catch", true);
            eat.SetActive(true);
            scream.SetActive(true);
            //cam1.SetActive(false);
            //cam2.SetActive(true);
        }
    }
}
