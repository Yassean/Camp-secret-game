using UnityEngine;

namespace NSkit3
{
public class kit3 : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
  
}
        public void hide()
        {
            Destroy(gameObject);
        }
    }
}
