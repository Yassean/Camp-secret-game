using UnityEngine;
using UnityEngine.UI;
using System.Collections;
public class blindlnessEffect : MonoBehaviour
{
   public GameObject img;
    public GameObject Gfall;
    public GameObject bang;
    public GameObject whiteNoise;
    private float timer = 3;
    public static blindlnessEffect activeInstance;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Gfall.SetActive(true);
        activeInstance = this;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void GoBlind()
    {
        StartCoroutine(goBlind(timer));
    }
    private IEnumerator goBlind(float time)
    {
        Debug.Log("explode");
        img.SetActive(true);
        bang.SetActive(true);
        whiteNoise.SetActive(true);
        yield return new WaitForSeconds(time);
        Debug.Log("go");
        bang.SetActive(false);
        img.SetActive(false);
        whiteNoise.SetActive(false);
        Gfall.SetActive(false);
        Destroy(gameObject);
    }
}
