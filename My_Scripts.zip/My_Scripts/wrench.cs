using UnityEngine;

namespace NSwrench
{
public class wrench : MonoBehaviour
{
        public GameObject Wire2;
        public GameObject spawner2;
        public GameObject hunt3;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
        public void hide()
        {
            Wire2.SetActive(true);
            Destroy(gameObject);
        }
    }
}

