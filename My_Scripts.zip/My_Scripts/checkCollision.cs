using StarterAssets;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class checkCollision : MonoBehaviour
{
    public GameObject spawner;
    public GameObject player;
    public FirstPersonController movement;
    public GameObject cam1;
    public GameObject cam2;
    public GameObject wireSound;
    public GameObject blood;
    public float timer=8;
    public GameObject flashSpawner2;
    public GameObject enemySpawner;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
      
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //void OnTriggerEnter(Collision collision)
    //{
    //    if (collision.collider.tag == "trigger1")
    //    {
    //        spawner.SetActive(true);
    //        Debug.Log("entered"+collision.collider.tag);
    //    }
    //}
    private void OnTriggerEnter(Collider other)
    {
        //if (other.gameObject.tag == "trigger1")
        //{
        //    spawner.SetActive(true);
        //   Debug.Log("entered"+other.tag);
        //}
        if (other.gameObject.tag == "trigger2"&&player.gameObject.tag=="Player")
        {
            movement.enabled = false;
           // look.enabled = true;
            Debug.Log("entered" + other.tag);
            cam1.SetActive(false);
            cam2.SetActive(true);
            blood.SetActive(true);
            StartCoroutine(CountDownCoroutine(timer));
        }
        if (other.gameObject.tag == "wire")
        {
            wireSound.SetActive(true);
            movement.MoveSpeed = movement.MoveSpeed / 4;
            movement.SprintSpeed = movement.SprintSpeed / 4;
        }
        if (other.gameObject.tag == "trigger1"&&player.gameObject.tag=="PlayerS")
        {
            flashSpawner2.SetActive(true);
            enemySpawner.SetActive(true);
        }
    }
    IEnumerator CountDownCoroutine(float time)
    {
       
        yield return new WaitForSeconds(time);
        player.GetComponent<FirstPersonController>().enabled = false;
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.None;
        SceneManager.LoadScene(0);
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "wire")
        {
            movement.MoveSpeed = movement.MoveSpeed *4;
            movement.SprintSpeed = movement.SprintSpeed * 4;
        }
    }
}
