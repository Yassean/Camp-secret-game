using UnityEngine;

public class spawner : MonoBehaviour
{
    public GameObject enemy;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Instantiate(enemy, transform.position, Quaternion.identity);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //public void spawn()
    //{
    //    Instantiate(enemy, transform.position, Quaternion.identity);
    //}
}
