using TMPro;
using UnityEngine;

public class wrenchUI : MonoBehaviour
{
    public GameObject player;
    private int wrenchTxT;
    public TextMeshProUGUI mainText;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        wrenchTxT = player.GetComponent<CameraDoorScript.CameraInteract>().Wrenches;
        mainText.text = wrenchTxT.ToString();
    }
}
