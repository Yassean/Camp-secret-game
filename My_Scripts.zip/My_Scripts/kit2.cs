using UnityEngine;

namespace NSkit2
{
public class kit2 : MonoBehaviour
{
        public GameObject timeLine;
        public GameObject spawner1;
        public GameObject Wire1;
        public GameObject hunt;
        public GameObject flashSpawner;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
          //  timeLine.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
        public void hide()
        {
            flashSpawner.SetActive(true);
            Wire1.SetActive(true);
            spawner1.SetActive(true);
            hunt.SetActive(true);
            Destroy(gameObject);
        }
    }
}

