using UnityEngine;
using TMPro;
public class kitsUi : MonoBehaviour
{
    public GameObject player;
    private int kitTxT;
    public TextMeshProUGUI mainText;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        kitTxT = player.GetComponent<CameraDoorScript.CameraInteract>().kits;
        mainText.text = kitTxT.ToString();
    }
}
