using UnityEngine;
namespace KeyScript
{
public class Key : MonoBehaviour
{
        public GameObject spawner3;
        public GameObject hunt2;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
        public void hide()
        {
            spawner3.SetActive(true);
            hunt2.SetActive(true);
            Destroy(gameObject);
        }
}

}
